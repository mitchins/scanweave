# M0-Q Gate Report — qualification closure

Date: 2024-10-14. Frozen baseline: commit `3172a32` (tag `m0-provisional-baseline`);
Q-phase work landed in commits after `9479414` (itemized in §2 and LEDGER.md).
Charter: operator message of 2024-10-14 (5 points). No architecture or interface
changes; THREE defect repairs are itemized in §2 (ink colour, ownership assignment,
hOCR 5.5 reader) — each is a concrete qualification-failure repair under the charter.

## 1. Reproduction (charter point 1) — PASS (re-run on the FINAL tree)

- Fresh clone → from-source build → full suite: **36 cargo tests pass** (incl. the E0
  four-part-key mutation property test), schema fixture layer green (3 positive / 6
  negative), checks.py 8 pages + 8/8 E-proofs, measure.py all B0 checks true.
- **32/32 acceptance artifacts byte-identical** between independent checkouts on the
  FINAL tree (out.pdf / out.ttf / b0_raster.pdf / b0_notext.pdf × 8 gate pages; full
  SHA-256 digests committed in `qualification/repro_hashcheck.json`; narrative in
  `qualification/REPRODUCTION.md`). An earlier truncated-digest spot-check existed only
  outside the tree (never committed); the committed record is the final-tree full-digest
  file produced after the §2 repairs.
- Commands, versions, exit codes recorded in REPRODUCTION.md.

## 2. Visual-failure characterization (charter point 2) — CHARACTERIZED; one defect REPAIRED; amendment DRAFTED (review pending)

**Defect repairs itemized (charter-sanctioned; disclosed per review finding B5):**
1. **Ink colour** (`mask.rs`/`pdf.rs`): reconstruction painted pure black over gray-30
   source ink — caught by the whole-page MAE gate; now repaints sampled source ink
   colour. Post-repair p01 poppler passes all criteria.
2. **Ownership assignment** (`units.rs`): greedy first-claim → tightest-containing-box
   (real OCR boxes overlap). This did NOT fix the touching-character loss (see §4 ⚠)
   and is disclosed as an algorithm-level repair in a freeze phase, taken because the
   prior assignment was measurably unfair on real OCR; the reproduction set was RE-RUN
   on the final tree (§1 note).
3. **hOCR 5.5 reader** (`hocr.rs`): char text directly inside cinfo spans (no `<u>`
   wrapper), single `x_conf`, word text = char concat when the word span has no direct
   text. Verified against real tesseract 5.5.0 output.

Evidence (`qualification/characterization.json`):

1. **600 dpi convergence: IoU 1.0 in BOTH engines** (p02 rendered at 600 dpi, downsampled
   to the 300 dpi grid vs source). The outlines and placement are geometrically correct;
   the 300 dpi binary-mask differences are rasterization detail.
2. **PDFium vs Poppler signed displacement** — per-page numbers from the committed
   `characterization.json` (NOT an aggregate): p01: mean |d| 0.257 px, 74.3% < 0.5 px,
   max 1.0 px, mean_dx −0.186; p04: mean |d| 0.475 px, 52.5% < 0.5 px, max 1.414 px
   (the `fi` page); p05: mean |d| 0.133 px, 86.7% < 0.5 px, max 1.0 px. Poppler-vs-
   source integer boundary displacement is 0.0 where the gate passes. Conclusion: PDFium's ~1.1 px p95 is AA-threshold wobble
   on shallow anti-aliased ramps (page-dependent), NOT a geometry or placement defect;
   p04's larger values track the disclosed 1 px `fi` placement deviation. No repair
   indicated for the wobble itself; no thresholds changed.
3. **p01 MAE 0.0206 — REAL DEFECT FOUND AND REPAIRED.** The decomposition showed the
   far-from-edge band contributing 60% of the absolute difference: the FIXTURE draws ink
   at gray 30 while the reconstruction painted PURE BLACK — a ~0.078–0.118 solid-ink
   colour change, i.e. a genuine visible-colour fidelity violation that the whole-page
   MAE gate correctly caught. REPAIR (charter-sanctioned): the probe now samples the
   source ink colour (median of foreground samples) and repaints glyphs in that colour
   (`mask.rs` `Segmentation.ink`, consumed by `pdf.rs`). Post-repair p01 poppler:
   IoU 1.000, edge p95 0.29 px, **MAE 0.0038** (pdfium 0.0052) — the page PASSES all
   dev-initial-1 criteria in Poppler. Lesson recorded: the gate was right; the defect
   was ours.
4. **p04 `fi` 1px**: sub-pixel metric confirms p95 1.01/1.07, max 1.32/1.07 — single-glyph,
   both engines, deterministic; unchanged from the M0 report disclosure.
5. **Caveat disclosed:** the planned rasterizer-independent outline ground-truth check
   (render the embedded TTF via PIL/cmap) produced no data — the probe's minimal nominal
   cmap maps OCR labels, and PIL resolved the test char to .notdef. Nominal-cmap
   completeness is deferred to M1; geometry ground truth is instead established by the
   600 dpi convergence (item 1).

**Proposed versioned policy amendment `m0-qual-1` (DRAFT — requires independent review
before adoption; current gates remain as-is until then; NARROWED after the ink-colour
repair removed the MAE driver):**
(a) geometric fidelity is judged by ink-mask IoU + sub-pixel symmetric edge distance
against the source ink;
(b) whole-page raw MAE stays as a gate (it caught a real defect) with the ink-weighted /
background-weighted split reported alongside (QUALIFICATION §4.2);
(c) the remaining pdfium edge p95 ~1.1 px is proposed to be treated as engine-AA
variance with an engine-paired criterion ONLY IF the M1 calibration data confirms the
outlines are sub-pixel accurate under pdfium at higher rendering resolutions. Nothing
is relaxed in this report.

## 3. Benign pilot corpus (charter point 3) — BLOCKED (environment)

- No corpus is mounted on this machine (checked 2024-10-14; filesystem scan recorded in
  the session ledger). Nothing was fabricated or substituted.
- Turnkey adapter delivered: `qualification/corpus_adapter.py` (expected layout,
  document-level manifest, split isolation, pixel-hash binding; see file header).
- When mounted: `<corpus-root>/<stratum>/<document>/*.png + *.hocr` → adapter → page
  bundles → the committed suite runs unchanged.

## 4. External baselines (charter point 4) — PASS (executed, settings recorded)

Built from pinned sources without root: libtiff 4.6.0 (sha256 88b3979e…) → leptonica
1.85.0 (sha256 3745ae3b…) → tesseract 5.5.0 (sha256 f2fb34ca…), OpenJPEG 2.5.2
(sha256 90e3896f…); OCRmyPDF 17.13.0 (venv); InternetArchive archive-pdf-tools 1.5.7
(commit 8fe8b5b7…) with ONE recorded 6-line compatibility shim (PyMuPDF ≥ 1.22 removed
`getPageImageList`; Python 3.12 has no legacy build — shim recorded in LEDGER.md).
Language data: eng.traineddata (tessdata_fast, sha256 7d4322bd…).

**Real-tesseract end-to-end (UC-01)**: Tesseract 5.5.0 `-c hocr_char_boxes=1` on a
realistic 300-dpi text page → hOCR (118 chars, 118 x_conf values) → `hocr2json`
(normalized, validated, granularity symbol) → reconstruction: 47 glyph shapes /
113 occurrences; qpdf ✓; OTS ✓; B0 transport full text.

**Comparative table — identical sources, same tesseract OCR:**

Committed numbers from `measurements.json` (`pages.p09_realtext`, harness-executed):

| Tool (p09 single page) | bytes | ink IoU | transport |
|---|---|---|---|
| source PNG | 37,740 | — | — |
| IA MRC (recode_pdf, JP2 `-r 500/750`) | 45,020 | 0.8452 | 118 chars |
| OCRmyPDF 17.13 (`--force-ocr --output-type pdf --optimize 0`) | 40,121 | 0.7077 | 118 chars |
| **ours B2 (reconstruction)** | **24,058** | **0.8307** | 113 chars ⚠ |
| ours B0 (searchable raster) | 50,304 | 0.8508 (render-neutrality verified) | 113 chars ⚠ |

**Repeated-text 4-page document (p10)** — committed harness numbers
(`measurements.json` `pages.p10_multipage`): source 164,141 B; ours B2 (per-page sum)
**100,282 B** = **0.59× OCRmyPDF (169,244 B)** and **0.53× IA MRC (189,213 B)**; B0
216,444 B. Repeated-glyph sharing works on real OCR (e.g. `o` reused across contexts:
gid2 cids [1,33]). Caveat: external tools ran on a true 4-page PDF; ours is a per-page
sum (multi-page assembly is M1) — recorded as an approximation direction, and the same
touching-character import loss (§4 ⚠) applies to our text layer on these 36-px pages.

**⚠ Known defect found and quantified (charter point 4's anti-fallback concern applies
to fidelity, and this is a fidelity-side loss):** on 36-px kerned text, touching
characters rasterize as ONE component; the M0 probe's disjoint ownership assigns the
component to one symbol and the paired symbol is dropped — **5 of 118 characters
(4.2%) lost in the normalized OCR import**, affecting OUR B0 and B2 text layers
EQUALLY (both extract 113 chars; the loss is in import segmentation, upstream of the
raster/reconstruction split — it is NOT a reconstruction-specific loss, and it is NOT
a tesseract misrecognition: tesseract's hOCR for this page is correct and the earlier
report examples that blamed tesseract were misattributed; corrected herewith).
B0's render still shows 100% of the ink (the pixels are all present in the raster);
the loss is text-layer-only. Component splitting / multi-symbol shared units is scoped
as the FIRST M1 ownership-solver item (SPEC §5.2/§5.3); an attempted text-merge repair
was REVERTED because it reordered characters (a §4.3 content-critical error class) —
revert verified by the reviewer's request and recorded here.

Settings caveat (recorded, per QUALIFICATION §3): OCRmyPDF ran with `--optimize 0`
(lossless image stage); its lossy modes would reduce size with fidelity cost. IA MRC
used default JP2 rates. No universal superiority over MRC is claimed; the operator's
expectation (when reconstruction helps) is what this table establishes on this material.

## 5. Consolidated gate list

| # | Criterion | Status | Evidence |
|---|---|---|---|
| 1 | Pipeline end-to-end (synthetic, 8 gate pages incl. p08) | PASS with one recorded exception: p08 pdfium transport ORDER diverges on the scattered-symbol layout (content complete; visual gates otherwise pass) | checks.py; probe_results.json (8 pages after Q-phase re-run) |
| 2 | Independent reproduction (36 tests, 32/32 artifacts byte-equal, 8 pages) | PASS | REPRODUCTION.md; repro_hashcheck.json |
| 3 | E0–E7 font-graph proofs | PASS (8/8) | probe_results.json + QDF re-parse (prior review) |
| 4 | Six negative schema fixtures, dual layer | PASS | validate_fixtures.py + Rust tests |
| 5 | B0 raster baseline (transport/neutral/qpdf) | PASS | measurements.json |
| 6 | External MRC baselines executed on identical sources | PASS | §4 table |
| 7 | Repeated-glyph coverage (no raster-fallback success claim) | PASS | §4 repeated-text table |
| 8 | Real-tesseract UC-01 import path | PASS | §4 + hocr2json |
| 9 | dev-initial-1 visual gate, all pages | **FAIL (honest)** | probe_results.json (pdfium AA edge ~1.1px on all pages; p04 `fi` IoU/edge; p06 topology+outliers; MAE now passes on every page post ink-colour repair) |
| 10 | `m0-qual-1` policy amendment | **BLOCKED (review pending)** | §2 draft |
| 11 | Benign corpus qualification | **BLOCKED (not mounted)** | §3 |
| 12 | Touching-character character loss on small kerned text | **FAIL (known defect, M1-scoped)** | §4 ⚠ (5/118 chars; B0 carries full text) |
| 13 | MRC/OCRmyPDF full-quality matrix (lossy modes, JP2 rates) | **BLOCKED (M1/M3 scope; settings recorded)** | §4 caveat |

## 6. Disposition

PROVISIONAL baseline stands. M0-Q closes points 1, 4, 6, 7, 8 as PASS; points 9–13 are
FAIL/BLOCKED with evidence and scoped fixes. Per the operator table this does not
authorize M1: point 12's ownership solver is the first M1 deliverable, and point 11
unblocks on corpus mount.
