//! Bounded whole-page tonal representation. Never used for native exceptions.
//! Fixed source-feature checks supplement independently inspected real pages.

pub(crate) const QUALITY: u8 = 98;

fn luminance(rgb: &[u8]) -> f64 {
    (54.0 * rgb[0] as f64 + 183.0 * rgb[1] as f64 + 19.0 * rgb[2] as f64) / 256.0
}

pub(crate) fn eligible(samples: &[u8], width: u32, height: u32, colors: u8) -> bool {
    if width < 512 || height < 512 || ![1, 3].contains(&colors) {
        return false;
    }
    let mut levels = [false; 256];
    for p in samples.chunks_exact(colors as usize) {
        levels[if colors == 1 { p[0] } else { luminance(p).round() as u8 } as usize] = true;
    }
    levels.iter().filter(|&&v| v).count() >= 64
}

/// Inspect every source pixel, including faint isolated dark ridges and thin
/// horizontal/vertical marks. No OCR rectangles or glyph assumptions are used.
pub(crate) fn preserves_details(original: &[u8], decoded: &[u8], width: u32, height: u32, colors: u8) -> bool {
    if ![1, 3].contains(&colors)
        || original.len() != decoded.len()
        || original.len() != width as usize * height as usize * colors as usize
        || original.iter().zip(decoded).any(|(&a, &b)| a.abs_diff(b) > 12)
    {
        return false;
    }
    let stride = colors as usize;
    let gray = |samples: &[u8], x: usize, y: usize| {
        let at = (y * width as usize + x) * stride;
        if colors == 1 {samples[at] as f64} else {luminance(&samples[at..at+3])}
    };
    for y in 1..height as usize - 1 {
        for x in 1..width as usize - 1 {
            let a = gray(original,x,y);
            let b = gray(decoded,x,y);
            for (p,q) in [((x-1,y),(x+1,y)),((x,y-1),(x,y+1))] {
                let contrast = gray(original,p.0,p.1).min(gray(original,q.0,q.1)) - a;
                if contrast < 8.0 {continue;}
                let retained = gray(decoded,p.0,p.1).min(gray(decoded,q.0,q.1)) - b;
                let minimum = if contrast >= 12.0 {contrast*0.5-1.0} else {2.0};
                if retained < minimum {return false;}
            }
        }
    }
    true
}

pub(crate) fn encode(samples: &[u8], width: u32, height: u32, colors: u8) -> Result<Option<Vec<u8>>,String> {
    if !eligible(samples,width,height,colors) {return Ok(None);}
    let mut jpeg = Vec::new();
    let color = if colors == 1 {image::ExtendedColorType::L8} else {image::ExtendedColorType::Rgb8};
    // image 0.25 encodes all RGB SOF sampling factors as 1x1 (4:4:4).
    // A regression checks emitted factors, independently of its stale doc comment.
    image::codecs::jpeg::JpegEncoder::new_with_quality(&mut jpeg,QUALITY)
        .encode(samples,width,height,color).map_err(|e|e.to_string())?;
    let decoded=image::load_from_memory_with_format(&jpeg,image::ImageFormat::Jpeg).map_err(|e|e.to_string())?;
    let data=if colors==1 {decoded.to_luma8().into_raw()} else {decoded.to_rgb8().into_raw()};
    if decoded.width()!=width || decoded.height()!=height || !preserves_details(samples,&data,width,height,colors) {
        return Ok(None);
    }
    Ok(Some(jpeg))
}
